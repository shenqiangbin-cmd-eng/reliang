# 🍎 食物热量识别工具

一个基于AI的智能食物热量识别网页工具，可以上传食物图片并自动分析热量信息。

## ✨ 功能特点

- 📸 **图片上传** - 支持点击上传和拖拽上传
- 🤖 **AI分析** - 集成豆包AI模型进行食物识别
- 📊 **热量分类** - 自动分类高、中、低热量食物
- 💯 **总热量计算** - 智能计算图片中所有食物的总热量
- 📱 **响应式设计** - 支持桌面和移动设备
- 🎨 **现代化UI** - 美观的渐变色设计和流畅动画

## 🚀 快速开始

1. 克隆项目到本地：
```bash
git clone https://github.com/shenqiangbin-cmd-eng/reliang.git
cd reliang
```

2. 启动本地服务器：
```bash
python3 -m http.server 8000
```

3. 在浏览器中打开：
```
http://localhost:8000
```

## 📁 项目结构

```
reliang/
├── index.html      # 主页面
├── style.css       # 样式文件
├── script.js       # 核心功能逻辑
└── README.md       # 项目说明
```

## 🔧 技术栈

- **前端**: HTML5, CSS3, JavaScript (ES6+)
- **AI模型**: 豆包 doubao-seed-1-6-flash-250715
- **API**: 火山引擎豆包API
- **设计**: 响应式布局，CSS Grid，Flexbox

## 🎯 使用方法

1. **上传图片**：点击上传区域或直接拖拽图片文件
2. **AI分析**：点击"分析热量"按钮，AI将自动识别食物
3. **查看结果**：在不同标签页查看分类结果
   - 🔥 高热量食物
   - ⚡ 中热量食物  
   - 🥬 低热量食物
   - 📊 总热量统计

## 🔑 API配置

项目使用火山引擎豆包API，需要配置以下信息：

```javascript
// 在script.js中配置
const API_URL = 'https://ark.cn-beijing.volces.com/api/v3/chat/completions';
const API_KEY = 'your-api-key-here';
const MODEL = 'doubao-seed-1-6-flash-250715';
```

## 🌟 特色功能

### 智能识别
- 支持多种食物类型识别
- 准确的热量估算
- 智能分类标记

### 用户体验
- 拖拽上传支持
- 实时预览
- 加载动画
- 响应式设计

### 数据展示
- 分类标签页
- 直观的热量标记
- 总热量统计

## 🤝 贡献

欢迎提交Issue和Pull Request来改进这个项目！

## 📄 许可证

MIT License

## 👨‍💻 作者

shenqiangbin-cmd-eng

---

**享受健康饮食，从了解食物热量开始！** 🥗✨